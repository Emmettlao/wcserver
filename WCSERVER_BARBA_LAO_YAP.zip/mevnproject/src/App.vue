// App.vue

<template>


<section>
<div id="app">
  <nav class="navbar fixed-top navbar-expand navbar-dark bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand navbar-logo" href="">The Basket</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav navbar-custom-cont">
        <li class="nav-cont">
          <router-link :to="{ name: 'Homepage' }" class="nav-link"><p>Home</p></router-link>
        </li>
        <li class="nav-cont">
          <router-link :to="{ name: 'Create' }" class="nav-link"><p>Shop</p></router-link>
        </li>
        <li class="nav-cont">
          <router-link :to="{ name: 'Index' }" class="nav-link"><p>Items</p></router-link>
        </li>
        <li class="nav-cont">
          <router-link :to="{ name: 'Contacts' }" class="nav-link"><p>Contact</p></router-link>
        </li>
      </ul>
    </div>
  </div>
  </nav>
  <transition name="fade">
      <div class="gap">
        <router-view></router-view>        
      </div>
  </transition>
</div>
</section>
</template>




<script>

export default {
}
</script>

<style>

  /*GLOBAL*/
  
   section {
  padding: 60px 0px;
  }

  /*NAVBAR*/

  .navbar-logo {
    padding-right: 1250px;
    padding-left: 100px;
  }
  
  .nav-cont{
  text-decoration: none;
  transition: all 0.3s ease;
  font-size: 25px;
  font-family: "Montserrat", sans-serif;
  padding-top: 22px;
  }

  .nav-cont p:hover{
    color: #00ffff;
  }

  /*BANNER*/

  .banner-library {
  background: url("./assets/header.jpg") center center no-repeat;
  background-size: cover;
  height: 87vh;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  background-attachment: fixed;
  }

  .banner-library img{
    height: auto;
    max-width: 100%;
    width: 600px;
  }

  .button-hp {
    margin-top: 20px;
    margin-bottom: 0px;
    padding: 13px 30px;
    text-decoration: none;
    border: 2px solid black;
    border-radius: 12px;
    color: black;
    background-color: gray;
    font-size: 22px;
    text-transform: uppercase;
  }
    
  .fade-enter-active, .fade-leave-active {
    transition: opacity .5s
  }

  .fade-enter, .fade-leave-active {
    opacity: 0
  }

  .title {
    text-align: center;
    font-size: 50px;
    font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif;
  }

  .intro {
    max-height: 100px;
    text-align: center;
  }

  .first {
    height: 400px;
  }

  .card {
    margin-top: 800px;
    width: 500px;
    margin-left: 400px;
    margin-bottom: 100px;
  }

  .card1 {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  max-width: 300px;
  margin: 10px;
  text-align: center;
  font-family: arial;
  float: left;
  margin-left: 50px;
  }

  .price {
    color: grey;
    font-size: 22px;
  }

  .footer {
    position: fixed;
    left: 0;
    bottom: 0;
    width: 100%;
    background-color: #212529;
    color: white;
    text-align: center;
    padding-bottom: 20px;
    padding-top: 20px;
    font-family: Arial, Helvetica, sans-serif;
  }

  .cont-us {
    text-align: center;
  }

  .cont-us h1{
    padding: 30px 0 30px;
  }

  .cont-us p {
    font-size: 20px;
  }





</style>