<template>
    <div class="back">
   <div class="img-col">
   <br>


<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d123285.22470555932!2d120.59123289507106!3d15.06672991791435!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3396f79f47a8aadb%3A0x2c4be1dddb81922a!2sSan%20Fernando%2C%20Pampanga!5e0!3m2!1sen!2sph!4v1621264353119!5m2!1sen!2sph" width="100%
" height="500" style="border:0;" allowfullscreen="" loading="lazy"></iframe>

</div>

<div class="text-col">
    <div class="cont-us">
   <h1>CONTACT US</h1>
    <p>shopthebasket@gmail.com</p>
    <p>0955-039-0120</p>
    </div>
</div>



<div class="footer">
   <h6>For more information, Visit Contacts page, Est 2021.</h6>
</div>
</div>
</template>