// Create.vue

<template>
  
<div class="container">
<hr>
<br>
<div class="card1">
  <img src="@/assets/bk.png" height="300px" width="250px" />
  <h2>Burger King</h2>
  <p class="price">50-1000PHP</p>
</div>
<div class="card1">
    <img src="@/assets/kfc.png" height="300px" width="250px" />
      <h2>KFC</h2>
  <p class="price">50-1000PHP</p>
</div>
<div class="card1">
    <img src="@/assets/jb.png" height="300px" width="250px" />
      <h2>Jollibee</h2>
  <p class="price">50-1000PHP</p>
</div>
<div class="card1">
    <img src="@/assets/ck.png" height="300px" width="250px" />
      <h2>Chicken</h2>
  <p class="price">50-1000PHP</p>
</div>
<div class="card1">
    <img src="@/assets/mcdo.png" height="300px" width="250px" />
      <h2>McDonalds</h2>
  <p class="price">50-1000PHP</p>
</div>
<div class="card1">
    <img src="@/assets/yellowcab.png" height="300px" width="250px" />
      <h2>Yellow Cab</h2>
  <p class="price">50-1000PHP</p>
</div>
<div class="card1">
    <img src="@/assets/sb.png" height="300px" width="250px" />
      <h2>Starbucks</h2>
  <p class="price">50-1000PHP</p>
</div>
<div class="card1">
    <img src="@/assets/bonchon.png" height="300px" width="250px" />
      <h2>Bon Chon</h2>
  <p class="price">50-1000PHP</p>
  
</div>
      <br><br><br>
        <div class="card">
            <div class="card-header">
                <h3>Add Item</h3>
            </div>
            <div class="card-body">
                <form v-on:submit.prevent="addItem">
                    <div class="form-group">
                        <label>Item Name:</label>
                        <input type="text" class="form-control" v-model="item.name"/>
                    </div>
                    <div class="form-group">
                        <label>Item Price:</label>
                        <input type="text" class="form-control" v-model="item.price"/>
                        <br>
                    </div>
                    <div class="form-group">
                        <input type="submit" class="btn btn-primary" value="Add Item"/>
                    </div>
                    <div class="footer">
                    <h6>For more information, Visit Contacts page, Est 2021.</h6>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
</template>

<script>
export default {
  component: {
      name: 'AddItem'
  },
  data() {
      return {
          item: {}
      }
  },
  methods: {
      addItem() {
           let uri = 'http://localhost:4000/items/add';
            this.axios.post(uri, this.item).then((response) => {
                console.log(response.data)
            });
        }
    }
}
</script>