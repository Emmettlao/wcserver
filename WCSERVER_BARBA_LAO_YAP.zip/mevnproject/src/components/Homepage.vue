<template>
   <div class="homepage-menu">      
      <div class="header">
         <div class="img-col">
            <div class="banner-library">
               <img src="@/assets/homepage2.png">
               <router-link :to="{ name: 'Create' }" class="button-hp">Shop now</router-link>
            </div>
         </div>
      </div>
   
     
   <div class="back">
      <div class="resto">
         
      </div>
   </div>





   <div class="footer">
      <h6>For more information, Visit Contacts page, Est 2021.</h6>
   </div>



   </div>   
</template>